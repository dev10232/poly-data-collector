/**
 * HTTP + WebSocket server for Polymarket real-time prices.
 * Serves static files from public/ and relays Polymarket WebSocket data to browser clients.
 */

const http = require('http');
const path = require('path');
const fs = require('fs');
const { WebSocketServer } = require('ws');

const { GammaClient } = require('./gamma_client');
const { MarketWebSocket } = require('./websocket_client');
const collector = require('./collector');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

// const COINS = ['ETH', 'BTC', 'SOL', 'XRP'];
// const INTERVALS = ['15m', '5m'];
const COINS = ['ETH', 'BTC', 'SOL', 'XRP'];
const INTERVALS = ['5m'];

/** asset_id -> { coin, interval, outcome, end_date_ms } */
const assetMeta = {};

/** Polymarket WS - single connection, shared subscriptions */
const polyWs = new MarketWebSocket();

/** Broadcast price updates to all browser clients */
let broadcastClients = new Set();

/** All markets structure for frontend */
let allMarkets = [];

polyWs.onPrice((assetId, midPrice, bestBid, bestAsk) => {
  const id = String(assetId);
  const meta = assetMeta[id];
  const msg = JSON.stringify({
    type: 'price',
    asset_id: id,
    mid_price: midPrice,
    best_bid: bestBid,
    best_ask: bestAsk,
    label: meta?.outcome || assetId.slice(0, 12) + '...',
    coin: meta?.coin,
    interval: meta?.interval,
    outcome: meta?.outcome,
    end_date: meta?.end_date,
  });
  broadcastClients.forEach((ws) => {
    if (ws.readyState === 1) ws.send(msg);
  });
  collector.onPriceUpdate(id, bestBid, bestAsk);
});

polyWs.onError((err) => console.error('[Poly WS]', err.message));

function broadcastMarkets() {
  const msg = JSON.stringify({ type: 'markets', markets: allMarkets });
  broadcastClients.forEach((ws) => {
    if (ws.readyState === 1) ws.send(msg);
  });
}

async function subscribeAllMarkets() {
  const oldTokenIds = polyWs.getSubscribedTokenIds();

  allMarkets.length = 0;
  Object.keys(assetMeta).forEach((k) => delete assetMeta[k]);

  const gamma = new GammaClient();
  const tokenIds = [];

  for (const coin of COINS) {
    for (const interval of INTERVALS) {
      const info = await gamma.getMarketInfo(coin, interval);
      if (!info?.token_ids) continue;

      const market = info.raw;
      const ids = info.token_ids;
      const upId = ids.up ? String(ids.up) : null;
      const downId = ids.down ? String(ids.down) : null;
      const endDate = info.end_date;
      const endMs =
        typeof endDate === 'string'
          ? new Date(endDate).getTime()
          : (endDate || 0) * 1000;

      if (upId) {
        tokenIds.push(upId);
        assetMeta[upId] = { coin, interval, outcome: 'Up', end_date: endMs };
      }
      if (downId) {
        tokenIds.push(downId);
        assetMeta[downId] = {
          coin,
          interval,
          outcome: 'Down',
          end_date: endMs,
        };
      }

      allMarkets.push({
        coin,
        interval,
        slug: market?.slug,
        end_date: endMs,
        duration_min: interval === '5m' ? 5 : 15,
        up_id: upId,
        down_id: downId,
      });
    }
  }

  if (tokenIds.length > 0) {
    if (oldTokenIds.length === 0) {
      await polyWs.subscribe(tokenIds, true);
    } else {
      // Market ended: close socket, wait for closed, update tokens (no send), run loop will reconnect and subscribe once
      await polyWs.closeConnection();
      polyWs.subscribe(tokenIds, true);
    }
  }
  collector.registerMarkets(allMarkets);
  broadcastMarkets();
}

const ETA_CHECK_INTERVAL_MS = 1000; // check every 1s

function anyMarketEnded() {
  const now = Date.now();
  return allMarkets.some((m) => (m.end_date || 0) - now <= 0);
}

void subscribeAllMarkets().then(() => {
  broadcastMarkets();
  polyWs.run();
  setInterval(() => {
    if (anyMarketEnded()) {
      void subscribeAllMarkets();
    }
  }, ETA_CHECK_INTERVAL_MS);
});

const server = http.createServer(async (req, res) => {
  const url = req.url === '/' ? '/index.html' : req.url;
  const filePath = path.join(PUBLIC_DIR, url.split('?')[0]);

  if (url.startsWith('/api/')) {
    const route = url.slice(5).split('?')[0];
    if (route === 'markets' && req.method === 'GET') {
      const coin = new URL(req.url, 'http://x').searchParams.get('coin');
      const interval = new URL(req.url, 'http://x').searchParams.get(
        'interval',
      );
      try {
        if (coin && interval) {
          const gamma = new GammaClient();
          const info = await gamma.getMarketInfo(coin, interval);
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(info || { error: 'No active market' }));
        } else {
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ markets: allMarkets }));
        }
      } catch (e) {
        res.statusCode = 500;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ error: e.message }));
      }
      return;
    }
    if (route === 'rounds' && req.method === 'GET') {
      const db = require('./db');
      const coin = new URL(req.url, 'http://x').searchParams.get('coin');
      const duration = new URL(req.url, 'http://x').searchParams.get(
        'duration',
      );
      const limit = new URL(req.url, 'http://x').searchParams.get('limit');
      try {
        const opts = {};
        if (coin) opts.coin = coin;
        if (duration) opts.duration = parseInt(duration, 10);
        if (limit) opts.limit = parseInt(limit, 10) || 100;
        const rows = db.queryRounds(opts);
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ rounds: rows }));
      } catch (e) {
        res.statusCode = 500;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ error: e.message }));
      }
      return;
    }
  }

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.statusCode = 403;
    res.end('Forbidden');
    return;
  }

  try {
    const stat = await fs.promises.stat(filePath);
    if (!stat.isFile()) {
      res.statusCode = 404;
      res.end('Not found');
      return;
    }
    const ext = path.extname(filePath);
    const types = {
      '.html': 'text/html',
      '.js': 'application/javascript',
      '.css': 'text/css',
      '.ico': 'image/x-icon',
      '.json': 'application/json',
      '.svg': 'image/svg+xml',
    };
    res.setHeader('Content-Type', types[ext] || 'application/octet-stream');
    fs.createReadStream(filePath).pipe(res);
  } catch (e) {
    if (e.code === 'ENOENT') {
      res.statusCode = 404;
      res.end('Not found');
    } else {
      res.statusCode = 500;
      res.end('Internal error');
    }
  }
});

const wss = new WebSocketServer({ server, path: '/ws' });

/** Build price snapshot from cached orderbooks for new clients. */
function buildPriceSnapshot() {
  const orderbooks = polyWs.orderbooks;
  const out = [];
  for (const [assetId, ob] of Object.entries(orderbooks)) {
    const meta = assetMeta[assetId];
    out.push({
      type: 'price',
      asset_id: assetId,
      mid_price: ob.mid_price,
      best_bid: ob.best_bid,
      best_ask: ob.best_ask,
      coin: meta?.coin,
      interval: meta?.interval,
      outcome: meta?.outcome,
      end_date: meta?.end_date,
    });
  }
  return out;
}

wss.on('connection', (ws) => {
  broadcastClients.add(ws);
  ws.send(JSON.stringify({ type: 'markets', markets: allMarkets }));
  const snapshot = buildPriceSnapshot();
  for (const msg of snapshot) {
    ws.send(JSON.stringify(msg));
  }
  ws.on('close', () => broadcastClients.delete(ws));
});

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
